ba taghyir max_n va max_q too test_maker.cpp mitoonid maximum n va q ke be codetoon dade mishe ro taghir bedid
esm codetoono bezarid 1.cpp va ba baghie code hayi ke too in zip hast too ye pooshe bezarid
in command ha ro benevisid:
    chmod +x cpp_judge.sh
    ./cpp_judge.sh
test ghalat ham too file test.txt mitoonid bebinid

BE YAD CHAYI NABAT HAYE BOOFE ...

Moein
